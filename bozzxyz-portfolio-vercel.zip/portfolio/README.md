# Bozzxyz — Web3 Portfolio

Personal portfolio of Ikbal Faozi (Bozzxyz).
Built with React + Vite. All content is editable from the DATA / THEMES / I18N objects at the top of `src/App.jsx`.

## Run locally
npm install
npm run dev

## Build
npm run build
